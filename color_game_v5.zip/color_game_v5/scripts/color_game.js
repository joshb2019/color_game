// ----------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------
// Declare constants and variables (Global scope)
// ----------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------
let colors = generateRandomColors(determineNumberOfSquares());
const mainContent = document.querySelector("#main-content");
let squares = document.querySelectorAll(".square");
let colorToGuess = pickRandomColor();
const colorDisplay = document.querySelector("#color-display");
let guessedColor = "";
let guessResult = document.querySelector("#guess-result");
const gameTitle = document.querySelectorAll("#game-title");
const colorTitle = document.querySelectorAll("#color-title");
const title = document.querySelector("#title");
const newColorsButton = document.querySelector("#new-colors");
const difficultyButtons = document.querySelectorAll(".difficulty");

// ----------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------
// Game logic (Global scope)
// ----------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------

// Set span in h1 = to rgb value that user must guess
colorDisplay.textContent = colorToGuess;
// Set colors of squares
inititalizeSquares();
// Start playing
for(let i = 0; i < squares.length; i++){
  // Assign click event to each square
  squares[i].addEventListener("click", function(){ 
  // Save guessed color
  guessedColor = this.style.backgroundColor;
  // Compare guessed color to color to be guessed
  if(colorToGuess === guessedColor){
    // User wins
    winGame();
  } else {
    // Hide square, make it unclickable, tell user guess is wrong
    loseGame(squares[i])
  }}); // End of anonymous function
} // End of loop

// Add event listeners to buttons
for(let i = 0; i < difficultyButtons.length; i++){
   difficultyButtons[i].addEventListener("click", function(){
    // Show that new difficulty level is selected if user picks one
    changeButton(this);
    // Generate new colors and set appropriate number of squares to them
    resetGame();
  }); // End of anonymous function
} // End of loop

// Reset game
newColorsButton.addEventListener("click", function(){
  resetGame();
}); // End of add event listener

// ----------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------
// Functions
// ----------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------

// ************************************************************************
// Name: generateRandomColors
// Description: Fills an array with randomly generated colors
// ************************************************************************
function generateRandomColors(numberOfColors){
  // Create empty array
  colorArray = [];
  // Add user-supplied number of colors to it
  for (let i = 0; i < numberOfColors; i++){
    // Generate random color and add to array
    colorArray.push(generateOneRandomColor());
  } // End of loop
  return colorArray;
} // End of generateRandomColors

// ************************************************************************
// Name: pickRandomColor
// Description: Randomly selects a an index from the array of random colors
// ************************************************************************
function pickRandomColor(){
  // Generate random number that falls within the range of the array's indeces
  let randomColorIndex = Math.floor(Math.random() * colors.length); 
  // Return color that matches that index
  return colors[randomColorIndex];
} // End of pickRandomColor

// ************************************************************************
// Name: generateOneRandomColor
// Description: Generates a random rgb color value
// ************************************************************************ 
function generateOneRandomColor(){
  // Create red value for rgb
  const redValue = generateRandomNumber(255);
  // Create green value for rgb
  const blueValue = generateRandomNumber(255);
  // Create blue value for rgb
  const greenValue = generateRandomNumber(255);
  // Put values together for full rgb color
  const rgbValue = "rgb(" + redValue + ", " + blueValue + ", " + greenValue + ")";
  return rgbValue;
} // end of generateOneRandomColor

// ************************************************************************
// Name: resetGame
// Description: Selects new colors, resets result of last game, and changes color of title
// ************************************************************************ 
function resetGame(){
  // Reset text on button that triggers reset
  newColorsButton.textContent = "New Colors";
  // Generate new random colors
  colors = generateRandomColors(determineNumberOfSquares());
  // Select new color for user to guess
  colorToGuess = pickRandomColor();
  // Set title to new color user must guess
  colorDisplay.textContent = colorToGuess;
  // Clear result of previous game
  guessResult.textContent = "";  
  // Remove all squares from board
  removeSquares(determineNumberOfSquares());
  // Create new squares and give htem colors
  inititalizeSquares();
  // Change background of title to default
  title.style.backgroundColor = "#232323";
} // End of resetGame

// ************************************************************************
// Name: changeButton
// Description: Activates one button and deactivates the others, when one is clicked
// ************************************************************************ 
function changeButton(clickedButton){
  // Make clicked button active
  clickedButton.classList.add("active", "btn-danger");
  // Make other buttons not active
  for(let i = 0; i < difficultyButtons.length; i++){
    if(difficultyButtons[i] != clickedButton){
      difficultyButtons[i].classList.remove("active", "btn-danger");
      difficultyButtons[i].classList.add("btn-info");
    } // End of conditional statement
  } // End of loop
} // End of changeButton

// ************************************************************************
// Name: determineNumberOfSquares
// Description: Determines how many squares are generated
// ************************************************************************
function determineNumberOfSquares(){
  // Declare variables and constants
  const easyButton = document.querySelector("#easy-button");
  const mediumButton = document.querySelector("#medium-button");
  const hardButton = document.querySelector("#hard-button");
  let numberOfSquares = 0;
  // Set difficult based on user selection
  if(easyButton.classList.contains("active")){
    // Easy selected
    numberOfSquares = 3;
  } else if(mediumButton.classList.contains("active")){
    // Difficult selected
    numberOfSquares = 6;
  } else if(hardButton.classList.contains("active")){
    // Hard selected
    numberOfSquares = 9;
  }// End of conditional statement
  return numberOfSquares;
} // End of determineNumberOfSquares

// ************************************************************************
// Name: inititalizeSquares
// Description: Assigns colors to squares and makes them hoverable
// ************************************************************************
function inititalizeSquares(){
  // Create as many squares as you have colors
  for(let i = 0; i < colors.length; i++){
    squares[i].style.backgroundColor = colors[i];
    squares[i].classList.add("playable");
  } // End of loop
} // End of inititalizeSquares

// ************************************************************************
// Name: winGame
// Description: Tells the user he/she is correct, changes text in change colors button, and changes title and squares to the correct color
// ************************************************************************
function winGame(){
  // Tell user guess is correct
  guessResult.textContent = "Correct!";
  // Change header to correct color
  title.style.backgroundColor = colorToGuess;
  // Remove opacity capability from squares
  for(let i = 0; i < squares.length; i++){
    squares[i].classList.remove("playable");
  } // End of loop
  // Change text in change colors button
  newColorsButton.textContent = "Play Again";
  // Change all squares to correct color
  for(let i = 0; i < colors.length; i++){
    squares[i].style.backgroundColor = colorToGuess;
  } // End of loop
} // End of winGame

// ************************************************************************
// Name: loseGame
// Description: Sets background of square to general background, tells user to try again
// ************************************************************************
function loseGame(square){
  // Make square disappear (Change square's background color to general background color)
  square.style.backgroundColor = "#232323";
  // Remove border and poacity hover
  square.classList.remove("playable");
  // Tell user guess is wrong
  guessResult.textContent = "Incorrect. Try again.";
} // End of loseGame

// ************************************************************************
// Name: generateRandomNumber
// Description: Generates a random number between 0 and 255
// ************************************************************************ 
function generateRandomNumber(maximumValue){
  randomNumber = Math.floor(Math.random() * (maximumValue + 1));
  return randomNumber;
} // End of generateRandomNumber
 
// ************************************************************************
// Name: removeSquares
// Description: Removes all squares from board
// ************************************************************************ 
function removeSquares(squaresToKeep){
  // Turn squares invisible
  for(let i = 0; i < squares.length; i++){
    if(i >= squaresToKeep){
      squares[i].classList.remove("playable");
    } // End of conditional statement
    squares[i].style.backgroundColor = "#232323";
  } // End of loop
} // End of remove squares     
